export default function Footer() {
  return (
    <footer className="text-center py-4">
      <p>© {new Date().getFullYear()} Novar HQ. All rights reserved.</p>
    </footer>
  );
}
